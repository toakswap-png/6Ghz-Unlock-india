# Magisk WiFi Country Code Changer

A Magisk module that overrides the WiFi country code on Android devices to bypass regional restrictions and enable access to WiFi channels that may be restricted in certain regions.

## Features

- **Country Code Override**: Forces the WiFi country code to "US" (United States)
- **Automatic WiFi Restart**: Automatically restarts WiFi after applying the country code change
- **Boot-time Execution**: Runs automatically after system boot completion
- **Non-intrusive**: Works in the background without user intervention

## How It Works

The module operates by:

1. **Waiting for Boot Completion**: The service waits until the system boot process is complete
2. **Setting Country Code**: Uses Android's `cmd wifi force-country-code` command to set the country code to "US"
3. **WiFi Restart**: If WiFi is currently enabled, it temporarily disables and re-enables WiFi to apply the changes

## Installation

### Prerequisites

- An Android device
- Magisk or Lygisk

**Tested on Poco X3 Pro with LineageOS 22.2 (Android 15) and Lygisk 29.0.**

### Installation Steps

1. Download the module ZIP file
2. Open Magisk App
3. Go to Modules section
4. Tap the "+" button and select the downloaded ZIP file
5. Reboot your device when prompted

## Usage

After installation, the module works automatically:

- **First Boot**: The module will apply the country code change after the first reboot
- **Subsequent Boots**: The module runs automatically on every boot
- **No Configuration**: No user interaction required

### Reverting Changes

1. Disable the module in Magisk App
2. Reboot the device

## Safety Notes

- This module modifies system-level WiFi settings
- The country code change may affect WiFi performance in some regions
- Always backup your device before installing Magisk modules
- This module is for educational and personal use only

## Legal Disclaimer

This module is provided as-is for educational purposes. Users are responsible for ensuring compliance with local laws and regulations regarding WiFi usage and frequency bands. The developers are not responsible for any legal issues arising from the use of this module.

## License

This project is licensed under the MIT license.
