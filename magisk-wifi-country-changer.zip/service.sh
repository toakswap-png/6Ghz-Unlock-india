{
    until [[ "$(getprop sys.boot_completed)" == "1" ]]; do
        sleep 15
    done

    cmd wifi force-country-code enabled US

    wifi_enabled=$(cmd wifi status | grep -c "Wifi is enabled" || echo "0")

    if [[ "$wifi_enabled" -eq 1 ]]; then
        cmd wifi set-wifi-enabled disabled
        sleep 2
        cmd wifi set-wifi-enabled enabled
    fi
} &
